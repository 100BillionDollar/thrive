

        </main>
    </div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.9.3/min/dropzone.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://cdn.quilljs.com/1.3.6/quill.js"></script>

<script src="../assets/js/admin.js"></script>
<script src="../assets/js/banner.js"></script>
<script src="../assets/js/ecosystem.js"></script>
<script src="../assets/js/whoweare.js"></script>
</body>
</html>

